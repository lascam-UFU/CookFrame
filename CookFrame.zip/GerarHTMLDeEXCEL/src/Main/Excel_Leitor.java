package Main;

import java.io.File;
import java.io.IOException;

import jxl.Sheet;
import jxl.Cell;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Excel_Leitor {
	private Workbook planilha; // objeto que receber� um instancia da planilha estudada
	private Sheet[] abas; // objeto que ser� a aba
	private File arquivo; // arquivo .xls que ser� lido
	
	public Excel_Leitor(String caminho_arq) {
		try {
			arquivo = new File(caminho_arq);
			planilha = Workbook.getWorkbook(arquivo);
			getAbas();
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
//	public void teste() {
//		
//		System.out.println(linha_lenght(0, 0));
//		
//		for(Cell c : getLinha(0,0)) {
//			System.out.println(c.getContents());
//		}
//	}
	
	public Cell[] getLinha(int index_linha, int index_aba) {
		if(index_linha < Main.QtLinhas[index_aba]) {
			Sheet aba = abas[index_aba];
			Cell[] linha = aba.getRow(index_linha);
			if(linha_vazia(linha)) return null;
			return linha;
		} else return null;
	}
	
	public int linha_lenght(int index_linha, int index_aba) {
		Sheet aba = abas[index_aba];
		Cell[] linha = aba.getRow(index_linha);
		if(linha_vazia(linha)) return -1;
		return linha.length;
	}
	
	public boolean linha_vazia(Cell[] linha) {
		for(Cell l : linha) {
			if(!l.getContents().equals("")) {
				return false;
			}
		}
		return true;
	}
	
	private void getAbas() {
		abas = planilha.getSheets();
//		for (Sheet a : abas) {
//			System.out.println(a.getName());
//		}
	}
	
}
