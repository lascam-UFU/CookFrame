package Main;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import jxl.Cell;

import org.w3c.dom.Element;

public class HTMLconstrutor {
	private XML xml;
	private Excel_Leitor ex;
	private String arq_dir;
	
	public HTMLconstrutor(Excel_Leitor ex, String arq_dir) {
		xml = new XML("html");
		construir_estrutura();
		
		this.ex = ex;
		this.arq_dir = arq_dir;
	}
	
	public void add_script(int[] scripts) {
		Element script = xml.criar_elemento("script");
		xml.add_atributo(script, "language", "javascript");
		xml.add_atributo(script, "type", "text/javascript");
		for(int i=0; i<scripts.length; i++) {
			xml.set_valor_elemento(script, Script.get(scripts[i]));
		}
		xml.add_filho(getHead(), script);
	}
	
	public void add_style(int style_table, int style_title, int style_paragrafo) {
		Element style = xml.criar_elemento("style");
		String codigo = "";
		codigo += Style.style_table(style_table);
		codigo += Style.style_titulo(style_title);
		codigo += Style.style_paragrafo(style_paragrafo);
//		codigo += Style.style_body();
		
		xml.set_valor_elemento(style, codigo);
		xml.add_filho(getHead(), style);
	}
	
	public void add_titulo1(String titulo) {
		Element div = xml.criar_elemento("div");
//		xml.add_atributo(div, "align", "center");
		
		Element h1 = xml.criar_elemento("h1");
//		xml.add_atributo(h1, "align", "center");
		xml.set_valor_elemento(h1, titulo);

		xml.add_filho(div, butao_voltar());
		xml.add_filho(div, h1);
		xml.add_filho(getBody(), div);
	}
	
	public void add_titulo(String titulo) {
		Element h1 = xml.criar_elemento("h1");
		xml.add_atributo(h1, "align", "center");
		xml.set_valor_elemento(h1, titulo);
		
		xml.add_filho(getBody(), h1);
	}
	
	public void add_titulo2(String titulo) {
		Element h2 = xml.criar_elemento("h2");
		xml.add_atributo(h2, "align", "center");
		xml.set_valor_elemento(h2, titulo);
		
		xml.add_filho(getBody(), h2);
	}
	
	private Element butao_voltar() {
		Element a = xml.criar_elemento("a");
		xml.add_atributo(a, "onClick", "history.go(-1)");
		xml.add_atributo(a, "id", "voltar");
//		xml.add_atributo(a, "align", "left");
		xml.set_valor_elemento(a, "voltar");
		return a;
	}
	
	public void add_subtitulo(String titulo) {
		Element h3 = xml.criar_elemento("h3");
		xml.set_valor_elemento(h3, titulo);
		xml.add_filho(getBody(), h3);
	}
	
//	public void add_paragrafo(String titulo, String paragrafo) {
//		Element p = xml.criar_elemento("p");
////		xml.add_filho(p, strong(titulo));
//		xml.add_filho(p, normal(paragrafo));
//		add_subtitulo(titulo);
//		xml.add_filho(getBody(), p);
//	}
	
	public void add_paragrafo(String titulo, String paragrafo) {
		Element p = xml.criar_elemento("p");
//		xml.add_filho(p, strong(titulo));
		String[] str = paragrafo.split("\n");
		for(String s : str) {
			xml.add_filho(p, normal(s));
			xml.add_filho(p, br());
		}
		add_subtitulo(titulo);
		xml.add_filho(getBody(), p);
	}
	
	public void add_paragrafo2(String paragrafo) {
		Element p = xml.criar_elemento("p");
		String[] str = paragrafo.split("\n");
		for(String s : str) {
			xml.add_filho(p, normal(s));
			xml.add_filho(p, br());
		}
		xml.add_filho(getBody(), p);
	}
	public void add_paragrafo3(String paragrafo) {
		Element p = xml.criar_elemento("p");
		xml.add_atributo(p, "id", "paragrafo_info");
		String[] str = paragrafo.split("\n");
		for(String s : str) {
			xml.add_filho(p, normal2(s, "span_info"));
			xml.add_filho(p, br());
		}
		xml.add_filho(getBody(), p);
	}
	
	private Element strong(String text) {
		Element strong = xml.criar_elemento("b");
		xml.set_valor_elemento(strong, text);
		return strong;
	}
	
	private Element normal(String text) {
		Element normal = xml.criar_elemento("span");
		xml.set_valor_elemento(normal, text);
		return normal;
	}
	
	private Element normal2(String text, String id) {
		Element normal = xml.criar_elemento("span");
		xml.add_atributo(normal, "id", id);
		xml.set_valor_elemento(normal, text);
		return normal;
	}
	
	private Element normal3(String text, String id) {
		Element normal = xml.criar_elemento("span");
		xml.add_atributo(normal, "id", id);
		Element b = xml.criar_elemento("b");
		xml.set_valor_elemento(b, text);
		xml.add_filho(normal, b);
		return normal;
	}
	
	private Element br() {
		return xml.criar_elemento("br");
	}
	
	public void add_br() {
		xml.add_filho(getBody(), br());
	}
	
	private Element cell_valor(Element el, Cell c) {
		if(!c.getContents().trim().isEmpty()) {
			String[] list = c.getContents().split("\n");
			for(String s : list) {
				xml.add_filho(el, normal(s));
				xml.add_filho(el, br());
			}
		} else {
			xml.add_filho(el, normal("NDA"));
		}
		return el;
	}
	
	public void add_separador() {
		Element HR = xml.criar_elemento("HR");
		xml.add_atributo(HR, "width", "60%");
		xml.add_atributo(HR, "aling", "center");
		xml.add_atributo(HR, "size", "30");
		xml.add_filho(getBody(), HR);
	}
	
	public void add_img(String nome_img) {
		Element img = xml.criar_elemento("img");
		xml.add_atributo(img, "src", "img/"+nome_img);
		xml.add_atributo(img, "alt", "Aqui tinha uma imagem!");
		xml.add_atributo(img, "width", "60%");
//		xml.add_atributo(img, "height", "350");
		xml.add_atributo(img, "style", "margin-left: 20%;");
		xml.add_filho(getBody(), img);
	}
	
	public void paragrafo_com_filtro(int index_aba, String[] filtro) {		
		filtro[0] = filtro[0].trim();
		filtro[1] = filtro[1].trim();
		
		int index = 0;
		Cell[] linha = ex.getLinha(index, index_aba);
		
		List<Element> elementos = new ArrayList<Element>();
		
		while(linha != null) {
			if(filtro[0].equals(linha[0].getContents().trim()) 
					&& filtro[1].equals(linha[4].getContents().trim())
					&& "CLASS Extends".equals(linha[5].getContents().trim())) {
				
				Element a = xml.criar_elemento("a");
				xml.add_atributo(a, "href", "javascript:newPopup('"+linha[8].getContents().replace("\n", "<br>")+"');");
				xml.add_atributo(a, "style", "display: inline;");
				
				Element img = xml.criar_elemento("img");
				xml.add_atributo(img, "src", "img/text.png");
				xml.add_atributo(img, "alt", "Clique Aqui!");
				xml.add_atributo(img, "width", "30");
				xml.add_atributo(img, "height", "40");
				
				Element div = xml.criar_elemento("div");
				xml.add_atributo(div, "align", "center");
				xml.add_atributo(div, "style", "background-color : transparent;");
				
				xml.add_filho(a, img);
				
				Element span = xml.criar_elemento("span");
				xml.set_valor_elemento(span, linha[1].getContents() + " extends " + linha[4].getContents());
				xml.add_atributo(span, "style", "display: inline;margin-right:5%;");

				xml.add_filho(div, span);
				xml.add_filho(div, a);
				
				elementos.add(div);
			}
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		if(!elementos.isEmpty()) {
			add_subtitulo("Extends Classe Hot-spot");
			add_paragrafo3("A seguir ser�o apresentadas classes espec�ficas da aplica��o exemplo que \"extends\" essa classe Hot-spot e podem ser uteis para a receita.");
			add_paragrafo4("Voc� PODE ter que criar ou alterar uma classe da aplica��o que extends "+filtro[1]+ "com no exemplo: \n",elementos);
		}
	}
	
	public void add_paragrafo4(String paragrafo, List<Element> elementos) {
		Element p = xml.criar_elemento("p");
		String[] str = paragrafo.split("\n");
		for(String s : str) {
			xml.add_filho(p, normal(s));
			xml.add_filho(p, br());
		}
		for(Element el : elementos) {
			xml.add_filho(p, el);
		}
		xml.add_filho(getBody(), p);
	}
	
	/*
	 * ==================================================================
	 * ==================      INDEX     ================================	
	 */
	
	public void criar_tabela_index(int index_aba) {
		Element table = xml.criar_elemento("table");
		xml.add_atributo(table, "align", "center");
		
		int index = 0;
		Cell[] linha = ex.getLinha(index, index_aba);
		
		if(linha != null) {
			xml.add_filho(table, criar_primeira_linha_index(linha));
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		while(linha != null) {
			xml.add_filho(table, criar_linha_index(linha));
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		xml.add_filho(getBody(), table);
	}
	
	private Element criar_linha_index(Cell[] linha){
		Element tr = xml.criar_elemento("tr");
		int cont = 0;
		String receita = "";
		String desc = "";
		for(Cell c : linha) {
			Element td = xml.criar_elemento("td");
			xml.add_atributo(td, "align", "center");
			
			if(cont == 0) {
				Element a = xml.criar_elemento("a");
				xml.add_atributo(a, "href", c.getContents()+".html");
				xml.set_valor_elemento(a, c.getContents());
				xml.add_filho(td, br());
				xml.add_filho(td, a);
				xml.add_filho(td, br());
				
				receita = c.getContents();
			} else {
//				xml.set_valor_elemento(td, cell_valor(c));
				xml.add_filho(td, br());
				td = cell_valor(td, c);
				xml.add_filho(td, br());
				if(cont == 1) desc = c.getContents();
			}
			cont++;
			xml.add_filho(tr, td);
		}

		Paginas.pagina2(receita, receita, desc);
		return tr;
	}
	
	private Element criar_primeira_linha_index(Cell[] linha){
		Element tr = xml.criar_elemento("tr");
		for(Cell c : linha) {
			Element th = xml.criar_elemento("th");
			xml.set_valor_elemento(th, c.getContents());
			xml.add_filho(tr, th);
		}
		return tr;
	}
	
	/*
	 * ==================================================================
	 * ==================================================================	
	 */
	public boolean tem_conteudo2(int index_aba, String[] filtro) {	
		filtro[0] = filtro[0].trim();
		filtro[1] = filtro[1].trim();
		
		int index = 0;
		Cell[] linha = ex.getLinha(index, index_aba);
		
		while(linha != null) {
			if(filtro[0].equals(linha[0].getContents().trim()) 
					&& filtro[1].equals(linha[3].getContents().trim())) {
				
				return true;
			}
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		return false;
	}
	
	public void criar_tabela2(int index_aba, int[] colunas, String[] filtro) {		
		filtro[0] = filtro[0].trim();
		filtro[1] = filtro[1].trim();
		
		int index = 0;
		Cell[] linha = ex.getLinha(index, index_aba);
		
		Element table = xml.criar_elemento("table");
		xml.add_atributo(table, "align", "center");
		
		index = 0;
		linha = ex.getLinha(index, index_aba);
		
		if(linha != null) {
			xml.add_filho(table, criar_primeira_linha(linha,colunas));
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		while(linha != null) {
			if(filtro[0].equals(linha[0].getContents().trim()) 
					&& filtro[1].equals(linha[3].getContents().trim())) {
				
				Element tr = criar_linha2(linha,colunas);
				xml.add_filho(table, tr);
			}
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		xml.add_filho(getBody(), table);
	}
	
	private Element criar_linha2(Cell[] linha, int[] colunas){			
		Element tr = xml.criar_elemento("tr");
		int col = 0;
		int pos = 0;
		
		for(Cell c : linha) {
			if(pos < colunas.length && col == colunas[pos]) {
				Element td = xml.criar_elemento("td");
				xml.add_atributo(td, "align", "center");
				
				if(col != 5) {		
					xml.add_filho(td, br());
					td = cell_valor(td, c);	
					xml.add_filho(td, br());	
				} else {
					Element a = xml.criar_elemento("a");
					xml.add_atributo(a, "href", "javascript:newPopup('"+c.getContents().replace("\n", "<br>")+"');");
					
					Element img = xml.criar_elemento("img");
					xml.add_atributo(img, "src", "img/text.png");
					xml.add_atributo(img, "alt", "Clique Aqui!");
					xml.add_atributo(img, "width", "50");
					xml.add_atributo(img, "height", "50");
					
					Element div = xml.criar_elemento("div");
					xml.add_atributo(div, "align", "center");
					xml.add_atributo(div, "style", "background-color : transparent;");
					
					xml.add_filho(a, img);
					xml.add_filho(div, br());
					xml.add_filho(div, a);
					xml.add_filho(div, br());
					xml.add_filho(td, div);
				}	
				xml.add_filho(tr, td);
				pos++;
			}
			col++;
		}
		
		return tr;
	}
	
	/*
	 * ==================================================================
	 * ==================================================================	
	 */
	
	public boolean tem_conteudo(int index_aba, String[] filtro) {	
		filtro[0] = filtro[0].trim();
		filtro[1] = filtro[1].trim();
		
		int index = 0;
		Cell[] linha = ex.getLinha(index, index_aba);
		
		while(linha != null) {
			if(filtro[0].equals(linha[0].getContents().trim()) 
					&& filtro[1].equals(linha[2].getContents().trim())) {
				
				return true;
			}
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		return false;
	}
	
	public void criar_tabela(int index_aba, int[] colunas, String[] filtro) {		
		filtro[0] = filtro[0].trim();
		filtro[1] = filtro[1].trim();
		
		int index = 0;
		Cell[] linha = ex.getLinha(index, index_aba);

		List<String> classes = new ArrayList<String>();
		String hotspot = "";
		
		while(linha != null) {
			if(filtro[0].equals(linha[0].getContents().trim()) 
					&& filtro[1].equals(linha[2].getContents().trim())) {
				
				if(!classes.contains(linha[1].getContents().trim())) {
					classes.add(linha[1].getContents().trim());
					hotspot = linha[2].getContents().trim();
				}
			}
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		for(String classe: classes) {
			String paragrafo1 = "Voc� pode ter que redefinir m�todos na classe da aplica��o que \"extends\" "+hotspot+".\n" +
								"Exemplo: "+classe+" extends "+hotspot+"\n";
			String paragrafo2 = "Voc� pode ter que redigir os seguintes m�todos para esta receita:\n";
			add_paragrafo2(paragrafo1);
			add_paragrafo("",paragrafo2);
			
			Element table = xml.criar_elemento("table");
			xml.add_atributo(table, "align", "center");
			
			index = 0;
			linha = ex.getLinha(index, index_aba);
			
			if(linha != null) {
				xml.add_filho(table, criar_primeira_linha(linha,colunas));
				index++;
				linha = ex.getLinha(index, index_aba);
			}
			
			while(linha != null) {
				if(filtro[0].equals(linha[0].getContents().trim()) 
						&& classe.equals(linha[1].getContents().trim())
						&& filtro[1].equals(linha[2].getContents().trim())) {
					
					Element tr = criar_linha(linha,colunas);
					xml.add_filho(table, tr);
				}
				index++;
				linha = ex.getLinha(index, index_aba);
			}
			
			xml.add_filho(getBody(), table);
		}
	}
	
	private Element criar_linha(Cell[] linha, int[] colunas){			
		Element tr = xml.criar_elemento("tr");
		int col = 0;
		int pos = 0;
		
		String texto1 = "", texto2 = "";
		String ini = "<font face=\"arial\" color=\"blue\">Comentario de c�digo:</font><br>";
		String separador = "<br><HR WIDTH=60%><br>" +
				"<font face=\"arial\" color=\"blue\">Exemplo de C�digo para a redefini��o do m�todo:</font><br>";
		for(Cell c : linha) {
			if(col == 7) texto1 = c.getContents();
			if(col == 8) texto2 = c.getContents();
			if(pos < colunas.length && col == colunas[pos]) {
				Element td = xml.criar_elemento("td");
				xml.add_atributo(td, "align", "center");
				if(col != 8) {	
					if(col != 9) {
						xml.add_filho(td, br());	
						td = cell_valor(td, c);	
						xml.add_filho(td, br());	
					} else {
						texto1 = c.getContents();
						texto2 = linha[10].getContents();
						if(texto2.trim().isEmpty()) texto2 = "NDA";
						Element a = xml.criar_elemento("a");
						xml.add_atributo(a, "href", "javascript:newPopup('"+ini+texto2.replace("\n", "<br>")+separador+texto1.replace("\n", "<br>")+"');");
						
						Element img = xml.criar_elemento("img");
						xml.add_atributo(img, "src", "img/text.png");
						xml.add_atributo(img, "alt", "Clique Aqui!");
						xml.add_atributo(img, "width", "50");
						xml.add_atributo(img, "height", "50");
						
						Element div = xml.criar_elemento("div");
						xml.add_atributo(div, "align", "center");
						xml.add_atributo(div, "style", "background-color : transparent;");
						
						xml.add_filho(a, img);
						xml.add_filho(div, br());
						xml.add_filho(div, a);
						xml.add_filho(div, br());
						xml.add_filho(td, div);
					}
				} else {
					if(texto2.trim().isEmpty()) texto2 = "NDA";
					Element a = xml.criar_elemento("a");
					xml.add_atributo(a, "href", "javascript:newPopup('"+ini+texto2.replace("\n", "<br>")+separador+texto1.replace("\n", "<br>")+"');");
					
					Element img = xml.criar_elemento("img");
					xml.add_atributo(img, "src", "img/text.png");
					xml.add_atributo(img, "alt", "Clique Aqui!");
					xml.add_atributo(img, "width", "50");
					xml.add_atributo(img, "height", "50");
					
					Element div = xml.criar_elemento("div");
					xml.add_atributo(div, "align", "center");
					xml.add_atributo(div, "style", "background-color : transparent;");
					
					xml.add_filho(a, img);
					xml.add_filho(div, br());
					xml.add_filho(div, a);
					xml.add_filho(div, br());
					xml.add_filho(td, div);
				}	
				xml.add_filho(tr, td);
				pos++;
			}
			col++;
		}
		
		return tr;
	}
	
	/*
	 * ==================================================================
	 * ==================================================================	
	 */
	
	public boolean tem_conteudo(int index_aba, String filtro) {
		int index = 0;
		Cell[] linha = ex.getLinha(index, index_aba);

		if(linha == null) return false;
		
		while(linha != null) {
			if(filtro.equals(linha[0].getContents().trim())) {
				return true;
			}
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		return false;
	}
	
	public void criar_tabela(int index_aba, int[] colunas, String filtro, boolean link, String TipoHotspot, String titulo, String paragrafo) {
		Element table = xml.criar_elemento("table");
		xml.add_atributo(table, "align", "center");
		
		filtro = filtro.trim();
		
		int index = 0;
		Cell[] linha = ex.getLinha(index, index_aba);

		boolean conteudo = false;
		while(linha != null) {
			if(filtro.equals(linha[0].getContents().trim()) 
					&& TipoHotspot.equals(linha[5].getContents().trim())) {
				conteudo = true;
				break;
			}
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		if(conteudo) {
			index = 0;
			linha = ex.getLinha(index, index_aba);
			
			add_subtitulo(titulo);
			add_paragrafo3(paragrafo);
			
			if(linha != null) {
				xml.add_filho(table, criar_primeira_linha(linha,colunas));
				index++;
				linha = ex.getLinha(index, index_aba);
			}
	
			while(linha != null) {
				if(filtro.equals(linha[0].getContents().trim()) 
						&& TipoHotspot.equals(linha[5].getContents().trim())) {
					xml.add_filho(table, criar_linha(linha,colunas,link, filtro));
				}
				index++;
				linha = ex.getLinha(index, index_aba);
			}
		}
		
		xml.add_filho(getBody(), table);
	}
	
	public void criar_tabela(int index_aba, int[] colunas, String filtro, boolean link) {
		Element table = xml.criar_elemento("table");
		xml.add_atributo(table, "align", "center");
		
		filtro = filtro.trim();
		
		int index = 0;
		Cell[] linha = ex.getLinha(index, index_aba);

		if(linha != null) {
			xml.add_filho(table, criar_primeira_linha(linha,colunas));
			index++;
			linha = ex.getLinha(index, index_aba);
		}

		while(linha != null) {
			if(filtro.equals(linha[0].getContents().trim())) {
				xml.add_filho(table, criar_linha(linha,colunas,link, filtro));
			}
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		xml.add_filho(getBody(), table);
	}
	
	private Element criar_linha(Cell[] linha, int[] colunas, boolean link, String filtro){
		Element tr = xml.criar_elemento("tr");
		String Hot_spot = "", comentario = "", assinatura = "";
		int col = 0;
		int pos = 0;
		for(Cell c : linha) {
			if(col == 6) assinatura = c.getContents();
			if(pos < colunas.length && col == colunas[pos]) {
				Element td = xml.criar_elemento("td");
				xml.add_atributo(td, "align", "center");
				
				if(pos == 0) {
					if(link) {
						Element a = xml.criar_elemento("a");
						xml.add_atributo(a, "href", filtro+"_"+c.getContents()+".html");
						xml.set_valor_elemento(a, c.getContents());
						xml.add_filho(td, br());
						xml.add_filho(td, a);
						xml.add_filho(td, br());
					} else {
						xml.add_filho(td, br());
						xml.set_valor_elemento(td, c.getContents());
						xml.add_filho(td, br());
					}
					
					Hot_spot = c.getContents();
				} else {
					td = cell_valor(td, c);
					comentario = c.getContents();
				}
				
				xml.add_filho(tr, td);
				
				pos++;
			}
			col++;
		}

		if(link) Paginas.pagina3(filtro+"_"+Hot_spot, Hot_spot, filtro, comentario, assinatura);
		return tr;
	}
	
	private Element criar_primeira_linha(Cell[] linha, int[] colunas){
		Element tr = xml.criar_elemento("tr");
		int col = 0;
		int pos = 0;
		for(Cell c : linha) {
			if(pos < colunas.length && col == colunas[pos]) {
				Element th = xml.criar_elemento("th");
				if(!c.getContents().toLowerCase().equals("nda")) {
					xml.set_valor_elemento(th, c.getContents());
				}
				xml.add_filho(tr, th);
				
				pos++;
			}
			col++;
		}
		return tr;
	}
	
	/*
	 * ==================================================================
	 * ==================================================================	
	 */
	public void criar_tabela(int index_aba) {
		Element table = xml.criar_elemento("table");
		xml.add_atributo(table, "align", "center");
		
		int index = 0;
		Cell[] linha = ex.getLinha(index, index_aba);
		
		if(linha != null) {
			xml.add_filho(table, criar_primeira_linha(linha));
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		while(linha != null) {
			xml.add_filho(table, criar_linha(linha));
			index++;
			linha = ex.getLinha(index, index_aba);
		}
		
		xml.add_filho(getBody(), table);
	}
	
	private Element criar_linha(Cell[] linha){
		Element tr = xml.criar_elemento("tr");
		for(Cell c : linha) {
			Element td = xml.criar_elemento("td");

			xml.add_atributo(td, "align", "center");
			
//			xml.set_valor_elemento(td, cell_valor(c));
			td = cell_valor(td, c);
			xml.add_filho(tr, td);
		}
		return tr;
	}
	
	private Element criar_primeira_linha(Cell[] linha){
		Element tr = xml.criar_elemento("tr");
		for(Cell c : linha) {
			Element th = xml.criar_elemento("th");
			xml.set_valor_elemento(th, c.getContents());
			xml.add_filho(tr, th);
		}
		return tr;
	}

	/*
	 * ==================================================================
	 * ==================================================================	
	 */
	
	public void salvar_arquivo(String nome) {
		xml.salvar_arquivo(arq_dir+nome+".html");
	}
//	public boolean arq_existe(String nome) {
//		File arq = new File(arq_dir+nome+".html");
//		return arq.exists();
//	}
	
	private void construir_estrutura() {
		Element head = xml.criar_elemento("head");
		Element body = xml.criar_elemento("body");
		
		Element raiz = xml.get_raiz();
		
		xml.add_filho(raiz, head);
		xml.add_filho(raiz, body);
	}
	
	private Element getBody() {
		return xml.get_filho(xml.get_raiz(), "body");
	}
	
	private Element getHead() {
		return xml.get_filho(xml.get_raiz(), "head");
	}
	
	public void add_paragrafo_personalizado() {
		Element p = xml.criar_elemento("p");
		xml.add_atributo(p, "id", "paragrafo_info");

		xml.add_filho(p, normal2("Um framework orientado a objetos utiliza t�cnicas t�picas de orienta��o � objetos para incorporar caracter�sticas flex�veis, os ", "span_info"));
		xml.add_filho(p, normal3("hot-spots s�o classes e m�todos do framework que", "span_info2"));
		xml.add_filho(p, normal2("devem ser usados de forma adequada para integrar as necessidades de aplica��es espec�ficas ao framework. Este cookbook apresenta um conjunto de Receitas para instanciar funcionalidades usando o framework JHotDraw, vers�o 5.3. Esta � uma documenta��o criada com base em exemplos, logo as sugest�es de atividades e exemplos s�o retirados de uma ou mais aplica��es exemplo e suas", "span_info2"));
		xml.add_filho(p, normal3(" classes espec�ficas", "span_info2"));
		xml.add_filho(p, normal2(", criadas para esta aplica��o e que usam algum hot-spot.", "span_info2"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal2("As Receitas apresentam informa��es sobre os hot-spots e exemplos de utiliza��o destes na instancia��o desta funcionalidade para outra aplica��o. Segue o tipo de informa��o que ser� apresentada.", "span_info"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal2("1.", "span_info2"));
		xml.add_filho(p, normal3("Uma lista de Atividades ", "span_info2")); 
		xml.add_filho(p, normal2("como Extender, Implementar e Usar um hot-spot do Framework para a execu��o da Receita.", "span_info2"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("i. Coment�rios de C�digo: ", "span_info"));
		xml.add_filho(p, normal2("Coment�rio de c�digo sobre a Classe hot-spot que pode ser usada.", "span_info2"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("ii. Assinatura da Classe hot spot.", "span_info"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("iii. Padr�o de Projeto: ", "span_info"));
		xml.add_filho(p, normal2("Padr�o de Projeto que deve ser seguido para usar a classe hot-spot. Pode n�o seguir padr�o de projeto, ent�o este campo ser� vazio.", "span_info2"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("iv. Metodos da classe hot-spot a serem possivelmente redefinidos (overriden) para a receita selecionada.", "span_info"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("a. Classe espec�fica da aplica��o exemplo que �extends� a classe hot-spot.", "span_info3"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("b. Nome do M�todo hotspot.", "span_info3"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("c. Par�metros deste m�todo hot-spot.", "span_info3"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("d. C�digo do M�todo hot-spot na Classe hot-spot.", "span_info3"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("e. Coment�rio de C�digo do M�todo hot-spot na Classe hot-spot", "span_info3"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("f. Exemplos de redefini��o do m�todo: ", "span_info3"));
		xml.add_filho(p, normal2("Apresenta um exemplo da redefini��o do m�todo na classe espec�fica da aplica��o exemplo, que usa o framework.", "span_info2"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("g. Coment�rios de C�digo do exemplo: ", "span_info3"));
		xml.add_filho(p, normal2(" Coment�rio de c�digo da redefini��o do m�todo na aplica��o exemplo.", "span_info2"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("v. Instancia��o de objetos das classes hot-spot", "span_info"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("a. Classe espec�fica da aplica��o exemplo em que o objeto da classe hot-spot � instanciado.", "span_info3"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("b. Coment�rio de c�digo da Classe espec�fica.", "span_info3"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("c. Exemplos de instancia��o do objeto : ", "span_info3"));
		xml.add_filho(p, normal2("Apresenta um exemplo de  instancia��o do objeto da classe hotspot na aplica��o exemplo. ", "span_info2"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("d. Coment�rios de C�digo do exemplo: ", "span_info3"));
		xml.add_filho(p, normal2("Coment�rio de c�digo da instancia��o do objeto da classe hotspot na aplica��o exemplo.", "span_info2"));
		xml.add_filho(p, br());
		xml.add_filho(p, normal3("vi. M�tricas do framework: ", "span_info"));
		xml.add_filho(p, normal2("A seguir s�o apresentadas as m�tricas de c�digo do framework JHotDraw.", "span_info2"));
		xml.add_filho(p, br());
		
//		xml.add_filho(p, normal2("", "span_info"));
//		xml.add_filho(p, normal3("", "span_info"));
//		xml.add_filho(p, normal2("", "span_info2"));
//		xml.add_filho(p, normal3("", "span_info2"));
//		xml.add_filho(p, br());
		
		xml.add_filho(getBody(), p);
	}
}
