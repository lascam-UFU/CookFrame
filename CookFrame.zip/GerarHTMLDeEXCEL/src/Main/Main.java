package Main;

import java.io.File;

public class Main {
	
	public static int[] QtLinhas = {32, 313, 119, 201, 148};
	
	public static void main(String[] args) {
		String xlt = "C:/Users/thiago/Desktop/Thiago/raquel/xls//teste.xls";
		String arq_dir = "C:/Users/thiago/Desktop/Thiago/raquel/xls/";
		
//		delte_arqs("C:/Users/Thiago/Desktop/RAQUEL/Teste html e excel/html");
		
		Excel_Leitor ex = new Excel_Leitor(xlt);
		
//		HTMLconstrutor html = new HTMLconstrutor(ex, arq_dir);
		
		Paginas.init(ex, arq_dir);
		Paginas.gerar();
		
		System.out.println("OK !!!");
	}
	
//	public static void delte_arqs(String dir) {
//		File folder = new File(dir);
//		if (folder.isDirectory()) {
//			File[] sun = folder.listFiles();
//			for (File toDelete : sun) {
//				toDelete.delete();
//			}
//		}
//	}

}
