package Main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XML {
	
	private Document doc;
	
	public XML(String raiz) {
		init(raiz);
	}
	
	private void init(String raiz) {
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			
			doc = docBuilder.newDocument();
			Element rootElement = doc.createElement(raiz);
			doc.appendChild(rootElement);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Element criar_elemento(String nome) {
		return doc.createElement(nome);
	}
	
	public void add_atributo(Element el, String nome, String valor) {
		el.setAttribute(nome, valor);
	}
	
	public void set_valor_elemento(Element el, String valor) {
		el.setTextContent(valor);
	}
	
	public void add_filho(Element pai, Element filho) {
		pai.appendChild(filho);
	}
	
	public String el_to_string(Element el) {
		Node node = el.cloneNode(true);
		StringWriter writer = new StringWriter();
		Transformer transformer;
		try {
			transformer = TransformerFactory.newInstance().newTransformer();
			transformer.transform(new DOMSource(node), new StreamResult(writer));
			String xml = writer.toString();
			return xml;
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public Element get_filho(Element el, String nome) {
		return (Element) el.getElementsByTagName(nome).item(0);
	}
	
	public Element get_raiz() {
		return doc.getDocumentElement();
	}
	
	public void salvar_arquivo (String caminho) {
		try {
			BufferedWriter buffWrite = new BufferedWriter(new FileWriter(caminho));
			
			String str = el_to_string(get_raiz());
			
//			if(caminho.contains("CH.ifa.draw.standard.DecoratorFigure.")) System.out.println(str);
			
			buffWrite.write(str);
			buffWrite.flush();
			buffWrite.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }	
	
//	public void salvar_arquivo (String caminho) throws TransformerConfigurationException, TransformerException {
//		File arquivo = new File(caminho);
//        
//        TransformerFactory transformerFactory = TransformerFactory.newInstance();
//        Transformer transformer = transformerFactory.newTransformer();
//        DOMSource source = new DOMSource(doc);
//        StreamResult result = new StreamResult(arquivo);
//
//        transformer.transform(source, result);
//    }
}
