package Main;

public class Script {
	
	public static String get(int script) {
		switch (script) {
			case 0: return popup();
	
			default: return "";
		}
	}
	
	private static String popup() {
		return 	"function newPopup(conteudo){" +
				"	varWindow = window.open('','pagina'," +
				"		\"width=350, height=255, top=100, left=110, scrollbars=yes\");" +
				"	var str1 = '<font face=\\\"Courier New\\\">';" +
				"	var str2 = '</font>';" +
				"	var param = str1.concat(conteudo);" +
				"	var param2 = param.concat(str2);" +
				"	varWindow.document.write(param2);" +
				"}";
	}
}
