package Main;

import java.io.File;

public class Paginas {
	
	private static Excel_Leitor ex;
	private static String arq_dir;
	
	public static void init(Excel_Leitor ex2, String arq_dir2) {
		ex = ex2;
		arq_dir = arq_dir2;
	}
	
	public static void gerar() {
		pagina1("index");
//		pagina2("teste", "Mover (Move) Figura");
	}
	
	private static void pagina1(String nome_arq) {
		HTMLconstrutor htmlCtr = new HTMLconstrutor(ex, arq_dir);
		htmlCtr.add_style(2, 1, 1);

		htmlCtr.add_titulo("Cookbook");
		htmlCtr.add_titulo2("Framework JHotDraw");
		htmlCtr.add_subtitulo("Sobre o Cookbook:");
		htmlCtr.add_paragrafo_personalizado();
		htmlCtr.add_subtitulo("Lista de Receitas:");
		htmlCtr.add_paragrafo3("A seguir s�o apresentadas as Receitas deste Cookbook. As informa��es de uma ou mais receitas PODEM ser uteis para realizar a atividade alvo. ");
		htmlCtr.criar_tabela_index(0);
		
		htmlCtr.salvar_arquivo(nome_arq);
	}
	
	public static void pagina2(String nome_arq, String filtro, String desc_reciet) {
		HTMLconstrutor htmlCtr = new HTMLconstrutor(ex, arq_dir);
		htmlCtr.add_style(2, 2, 1);
		htmlCtr.add_titulo1("Receita: "+filtro);
		htmlCtr.add_paragrafo("Descri��o: ", desc_reciet);
		htmlCtr.add_subtitulo("Lista de Classes Hot-spot:");
		htmlCtr.add_paragrafo3("A seguir s�o apresentadas as Classes hot-spots do framework que podem ser usadas  na aplica��o exemplo para as funcionalidades tratadas por esta receita.  Estas PODEM ser uteis para a sua atividade.");

		htmlCtr.criar_tabela(1, new int[] {4,7}, filtro, true, "CLASS Extends"
				,"Estender Classe Hot-spot (extends Classe Hot-spot)"
				,"A seguir s�o apresentadas as Classes hot-spots do framework que PODEM ser estendidas (\"extends\")  "
						+ "na aplica��o exemplo para as funcionalidades tratadas por esta receita.");
		
		htmlCtr.criar_tabela(1, new int[] {4,7}, filtro, true, "INTERFACE"
				,"Implementar Interface (implements Interface Hot-spot)"
				,"A seguir s�o apresentadas as Interfaces hot-spots do framework que PODEM ser estendidas "
						+ "(\"implements\")  na aplica��o exemplo para as funcionalidades tratadas por esta receita.");

		htmlCtr.criar_tabela(1, new int[] {4,7}, filtro, true, "CLASS COLABORATE"
				,"Colaborar com Classe Hotspot"
				,"A seguir s�o apresentadas as Classes hot-spots do framework que PODEM ser  usadas "
						+ "(ex: instancia��o de objeto)  na aplica��o exemplo para as funcionalidades tratadas por esta receita.");

		htmlCtr.criar_tabela(1, new int[] {4,7}, filtro, true, "CLASS Extends do Extends"
				,"Herdar de Super Classes"
				,"A seguir s�o apresentadas as Classes hot-spots do framework que PODEM ser  usadas por heran�a "
						+ "(ex: invoca��o de algum m�todo de super classe hot-spot)  na aplica��o exemplo para as "
						+ "funcionalidades tratadas por esta receita. Esta lista contempla casos como:  A extends B e B "
						+ "extends C, logo A pode usar m�todos de C.");
		
		htmlCtr.salvar_arquivo(nome_arq);
	}
	
	public static void pagina3(String nome_arq, String filtro, String filtro2, String comentario, String assinatura) {
		HTMLconstrutor htmlCtr = new HTMLconstrutor(ex, arq_dir);
//		if(!htmlCtr.arq_existe(nome_arq)) {
			htmlCtr.add_style(2, 2, 1);
			htmlCtr.add_script(new int[] {0});
			htmlCtr.add_titulo1("Classe Hot-Spot");
			htmlCtr.add_titulo2(filtro);
			
			htmlCtr.add_paragrafo3("A seguir ser�o apresentadas informa��es  e exemplos de uso deste hot-spot para a(s) funcionalidade(s) tratada(s) pela Receita selecionada.");
			htmlCtr.add_paragrafo("Comentario de C�digo: ", comentario);
			htmlCtr.add_paragrafo("Assinatura da Classe: ", assinatura);

			if(htmlCtr.tem_conteudo(4, filtro)) {
				htmlCtr.add_subtitulo("Padr�o de Projeto");
				htmlCtr.criar_tabela(4, new int[] {1,2,3}, filtro, false);
			}
			
			htmlCtr.paragrafo_com_filtro(1, new String[] {filtro2, filtro});
			
			if(htmlCtr.tem_conteudo(2, new String[] {filtro2, filtro})) {
				htmlCtr.add_subtitulo("Redefini��es e Invoca��es de M�todos do Hotspot");
				htmlCtr.add_paragrafo3("A seguir ser�o apresentadas as  redefini��es e invoca��es de  m�todos  hot-spot desta classe hot-spot que podem ser uteis para esta Receita.");
				htmlCtr.criar_tabela(2, new int[] {3,4,6,8,9}, new String[] {filtro2, filtro});
			}
			
			if(htmlCtr.tem_conteudo2(3, new String[] {filtro2, filtro})) {
				htmlCtr.add_subtitulo("Instancia��es do Hotspot");
				htmlCtr.add_paragrafo3("A seguir ser�o apresentadas as instancia��es de objetos desta classe hot-spot.");
				htmlCtr.criar_tabela2(3, new int[] {1,2,5,6}, new String[] {filtro2, filtro});
			}
			
			htmlCtr.add_subtitulo("M�tricas do Framework JHotDraw:");
			htmlCtr.add_paragrafo3("A seguir s�o apresentadas as m�tricas de c�digo do framework JHotDraw.");
			htmlCtr.add_img("metricas.jpg");
			htmlCtr.add_br();
			
			htmlCtr.salvar_arquivo(nome_arq);
//		}
	}
	
//	public static void pagina0(String nome_arq, String texto1, String texto2) {
//		HTMLconstrutor htmlCtr = new HTMLconstrutor(ex, arq_dir);
//		if(!htmlCtr.arq_existe(nome_arq)) {
//			htmlCtr.add_style(1, 0, 0);
//			htmlCtr.add_titulo("C�digo Java");
//			htmlCtr.add_paragrafo2(texto1);
//			htmlCtr.add_separador();
//			htmlCtr.add_paragrafo2(texto2);
//			htmlCtr.salvar_arquivo(nome_arq);
//		}
//	}
	
}
