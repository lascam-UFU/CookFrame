package Main;

public class Style {

	public static String style_paragrafo(int index) {
		switch(index) {
			case 0: return style_paragrafo1();
			case 1: return style_paragrafo2(); 
			default: return "";
		}
	}
	
	public static String style_titulo(int index) {
		switch(index) {
			case 0: return style_titulo1();
			case 1: return style_titulo2(); 
			case 2: return style_titulo3(); 
			default: return "";
		}
	}
	
	public static String style_table(int index) {
		switch(index) {
			case 0: return style_tabela1();
			case 1: return style_tabela2();
			case 2: return style_tabela3();
			default: return "";
		}
	}
	
	public static String style_body() {
		String codigo = "" +
						"body {text-align: center;}" +
						""
						;
		return codigo;
	}
	
	private static String style_paragrafo1() {
		String codigo = "" +
						"p {width: 60%;font-family: Arial;border: 1px solid powderblue;" +
						"margin-left: 20%;text-align: justify;background: #b3d9ff;}" +
						"span {font-family:times new roman;}" +
						""
						;
		return codigo;
	}
	
	private static String style_paragrafo2() {
		String codigo = "" +
						"p {width: 60%;font-family: calibri;border: 1px solid powderblue;" +
							"margin-left: 20%;text-align: justify;background: #e7e7e7;border:1pt solid #cccccc;}" +
						"span {margin-left: 5%;font-family: calibri;}" +
						"#paragrafo_info {width: 60%;margin-left: 20%;text-align: justify;background: #ffffff;" +
							"border-color: transparent}" +
						"#span_info {font-style: italic;font-family: times new roman; color: #6699cc;}" +
						"#span_info2 {margin-left: 0%;font-style: italic;font-family: times new roman; color: #6699cc;}" +
						"#span_info3 {margin-left: 10%;font-style: italic;font-family: times new roman; color: #6699cc;}" +
						"span {margin-left: 5%;font-family: calibri;}" +
						""
						;
		return codigo;
	}
	
	private static String style_titulo1() {
		String codigo = "" +
						"div {clear: both;color:#FFF;background-color:#004d99;margin-bottom:5px;padding:15px;}" +
						"h1 {margin-left: 14%;display: inline;font-family: Arial,Helvetica Neue,Helvetica,sans-serif;" +
						"text-shadow: 2px 3px #1a53ff;font-size: 200%;}" +
						"button {display: inline;background-color: Transparent;" +
						"background-repeat:no-repeat;border: none;cursor:pointer;overflow: hidden;outline:none;}" +
						"h3 {margin-left: 20%;font-family: calibri; color:#004466;}" +
						""
						;
		return codigo;
	}
	
	private static String style_titulo3() {
		String codigo = "" +
						"div {clear: both;margin-left: 20%; width: 60%;background-color:#333333;" +
							"border-top-left-radius:0.5em;border-top-right-radius:0.5em;}" +
						"h1 {display: inline;font-family: calibri;margin-left: 20%;" +
							"font-size: 200%;color:#ffffff;}" +
						"#voltar {background-color: Transparent;" +
							"background-repeat:no-repeat;border: none;cursor:pointer;overflow: hidden;outline:none;" +
							"color:#ffffff}" +
						"h3 {margin-left: 20%;font-family: calibri; color:#004466;}" +
						""
						;
		return codigo;
	}
	
	private static String style_titulo2() {
		String codigo = "" +
						"h1 {margin-left: 20%; width: 60%; background-color:#333333; font-family: calibri; " +
						"font-size: 200%; color:#ffffff;" +
						"border-top-left-radius:0.5em;border-top-right-radius:0.5em;}" +
						"h3 {margin-left: 20%;font-family: calibri; color:#004466;}" +
						""
						;
		return codigo;
	}
	
	private static String style_tabela1() {
		String codigo = "" +
						"table {width: 60%;}" +
						"td {border-right: 2.5pt solid #d6dadb;border-top:3pt solid #d6dadb;border-radius:10px;background: #c9cccf;}" +
						"th {background: #6c737a;color: white;}" +
						"td:hover {background-color: #99ccff;border-color: #b3d9ff;}" +
						""
						;
		return codigo;
	}
	
	private static String style_tabela2() {
		String codigo = "" +
						"table {width: 60%;font-family:times new roman;}" +
						"td {border-right: 2.5pt solid #d6dadb;border-top:3pt solid #d6dadb;border-radius:10px;" +
							"background: #e0ebeb;text-align: left;}" +
						"th {background: #004d99;color: white;}" +
						"td:hover {background-color: #99ccff;border-color: #b3d9ff;}" +
						""
						;
		return codigo;
	}
	
	private static String style_tabela3() {
		String codigo = "" +
						"table {width: 60%;font-family:calibri;border-collapse: collapse;" +
						"border-left: 5pt solid #e7e7e7;border-right: 5pt solid #e7e7e7;}" +
						"td {border-bottom: 1pt solid #cccccc; border-right: 3pt solid #ffffff;" +
							"background: #ffffff;text-align: left;}" +
						"th {background: #e7e7e7;color: #767676;border: 1pt solid #ededed;}" +
						"td:hover {background-color: #dddddd;border-color: #999999;}" +
						"" +
						""
						;
		return codigo;
	}
	
}
